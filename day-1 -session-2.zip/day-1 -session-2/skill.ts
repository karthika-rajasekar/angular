export interface Skill{
    id: string,
    name: string
}